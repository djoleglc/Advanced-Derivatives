import numpy as np 
import scipy.stats
import scipy
import math 


def calc_vega(t, T, s, k, r, sigma):
        d1 = calc_d1(t, T, s, k, r, sigma)
        return s * scipy.stats.norm.pdf(d1) * np.sqrt(T-t)
    
def calc_d1(t, T, s, k, r, sigma, q=0 ):
        return ( np.log(s/k) + (r  - q + 0.5*sigma**2)*(T-t) )/(sigma * np.sqrt(T-t))
    
    
def implied_vol(PriceCall, t, T, S, K, r, start, method = "newton", precision = 10**(-5.5)):
    epsilon = precision
    old = start
    diff, gap_price = 1, 1
    
    if method == "newton":
        while diff > epsilon:
            gap_price = black_scholes_call(t,T,S, K, r, old ) - PriceCall
            new = old - gap_price/calc_vega(t, T, S, K, r, old)
            diff = np.abs(new - old)
            old = new
        return old, gap_price
    
    if method == "halleys":
        while diff > epsilon:
                gap_price = black_scholes_call(t,T,S, K, r, old ) - PriceCall
                vega = calc_vega(t, T, S, K, r, old)
                d1 = calc_d1(t, T, S, K, r, old)
                vomma = vega*d1*(d1 - old *np.sqrt(T-t))/old
                denominator = 2*vega**2 - gap_price * vomma
                
                new = old - 2*vega*gap_price/denominator
                diff = np.abs(new - old)
                old = new  
        return old, gap_price


def black_scholes_call(t, T, s, k, r, sigma, q = 0):
    d1 = ( np.log(s/k) + (r - q + 0.5*sigma**2)*(T-t) )/(sigma * np.sqrt(T-t))
    d2 = d1 - sigma * np.sqrt(T-t)
    price = s * np.exp(-q *(T-t))*scipy.stats.norm.cdf(d1) - k*np.exp(-r *(T-t))*scipy.stats.norm.cdf(d2)
    return price



def zeta(deltaK, deltaT, sig):
    return 0.5 * deltaT/(deltaK ** 2) * sig **2



def fill_piecewise(x, val):
    """values are the values to use, it must have the same length as the number of elements of
    x that are not equal to 0 """ 
    x, val = np.array(x), np.array(val)
    """ creation of an array to fill """ 
    y = np.zeros(len(x))    
    """ 
        get the position where element in x are not zero 
        from x we care only about the index where the values are not zero    
    """ 

    ind = np.where(x!=0)[0]
    temp = 0
    for j in np.arange(len(x)):
        if j <= ind[temp]:
            """
               if the index associated with the value we need to fill is smaller than the reference one
                then fill y with the values coming from the array of values, or dictionary 
            """
            y[j] = val[temp]
        else:
            temp = np.min([temp+1, len(ind)-1])
            y[j] = val[temp]
    return y 



def fill_piecewise_int(y, val):
    """ 
    values are the values to use, it must have the same length as the number of elements of
    x that are not equal to 0 
    """
    y, val = np.array(y), np.array(val) 
    y[y!=0] = val
    
    """
    interpolation 
    creation of the two arrays to "train"
    """
    xp = np.where(y!=0)[0]
    fp = y[y!=0]
    x  = np.where(y==0)[0]
    y[np.where(y==0)[0]] = np.interp(x, xp, fp)
    
    return y


    
    